angular.module("adventureGameApp")
    .constant("globalSettings", {
        gameBoardWidth: 17,
        gameBoardHeight: 17
    });
