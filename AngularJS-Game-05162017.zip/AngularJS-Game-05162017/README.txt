I wanted to learn AngularJS so I taught myself by creating this game.

Open index.html in your browser in order to play.